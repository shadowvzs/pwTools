<?php 

function SysSendMail(){
	$Receiver = 1024;
	$Title = "New Mail";
	$Message = "We send an item with mail!";
	$ItemID = 25957;
	$Count = 1;
	$Count_Max = 1;
	$Octets = "0100db000300000003000000e8030000d00700002c00030000000000090000000100000000000000010000000100000000000000000000001800000000006040000000000000000000000000";
	$Proctype = 19;
	$Expire_date = 0;
	$Guid1 = 0;
	$Guid2 = 0;
	$Mask = 1;
	$Money = 3333;
	
	$tID = "\x00\x00\x01\x58";
	$SysID = "\x00\x00\x00\x20";
	$SysType = "\x03";
	
	$Receiver = pack("N*", $Receiver);
	$Title = iconv("UTF-8", "UTF-16LE", $Title);
	$TitleLengh = strlen($Title);
	if($TitleLengh < 128){
		$TitleLengh = pack("C*", $TitleLengh);
	}else{
		$TitleLengh = pack("n*", $TitleLengh + 32768);
	}
	$Message = iconv("UTF-8", "UTF-16LE", $Message);
	$MessageLengh = strlen($Message);
	if($MessageLengh < 128)	{
		$MessageLengh = pack("C*", $MessageLengh);
	}else{
		$MessageLengh = pack("n*", $MessageLengh + 32768);
	}
	$ItemID = pack("N*", $ItemID);
	$Pos = "\x00\x00\x00\x00";
	$Count = pack("N*", $Count);
	$Count_Max = pack("N*", $Count_Max);
	$Octets = pack("H*", $Octets);
	$OctetsLenght = pack("n*", strlen($Octets) + 32768);	
	$OctetsLenght = pack("n*", strlen($Octets) + 32768);	
	$Proctype = pack("N*", $Proctype);
	$Expire_date = pack("N*", $Expire_date);
	$Guid1 = pack("N*", $Guid1);
	$Guid2 = pack("N*", $Guid2);
	$Mask = pack("N*", $Mask);
	$Money = pack("N*", $Money);
	$Err = 0;
	$Packet = $tID.$SysID.$SysType.$Receiver.$TitleLengh.$Title.$MessageLengh.$Message.$ItemID.$Pos.$Count.$Count_Max.$OctetsLenght.$Octets.$Proctype.$Expire_date.$Guid1.$Guid2.$Mask.$Money;
		$PacketLenght = strlen($Packet);
		if($PacketLenght < 128)
		{
			$PacketLenght = pack("C*", $PacketLenght);
		}else{
			$PacketLenght = pack("n*", $PacketLenght + 32768);
		}

	$Packet = "\x90\x76".$PacketLenght.$Packet;
	$len = strlen($Packet);
	echo "<br><br>len: $len <br>";
	for ($i=0;$i<$len;$i++) {
		echo dechex(ord(substr($Packet, $i, 1))).'-';
	}
	die('-');
	$sock = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
	if(!$sock){
			die(socket_strerror(socket_last_error()));
	}

	$GameServer = "localhost";
	if(socket_connect($sock, $GameServer, 29100)){
		socket_set_block($sock);
		if (false !== ($sbytes = socket_send($sock, $Packet, 8192, 0)))	{	
		}else{
			$Err = 1;
		}
		if (false !== ($rbytes = socket_recv($sock, $buf, 8192, 0))){
		}else{
			$Err = 2;
		}
        socket_set_nonblock($sock);
        socket_close($sock);
	}else{
		$Err = 3;
	}
	
	return $Err;
}

SysSendMail();
?>
