<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Веб-панель редактор должностей в клане v1.3(C) webserverok.com</title>
</head>
<body style='text-align: left;'>
<?php

$lvl = array(0=>1,1=>2,2=>3);
function SocketSender($Data, $host, $port){
	$Socket = socket_create(AF_INET,SOCK_STREAM,SOL_TCP);
	if(socket_connect($Socket,$host,$port)) {
	    socket_set_block($Socket);
		$send = socket_send($Socket,$Data,8192,0);
	    $recv = socket_recv($Socket,$buf,8192,0);  
	    socket_set_nonblock($Socket);
	    socket_close($Socket);
	} else { 
		getErrorMessage(7,'die','feedback'); 
	}
}	

function dbread($table){ 
	$bdlen = pack("n*", strlen($table)+32768);
	$data = pack('N', -1).$bdlen.$table.pack('N', 0);
	$Socket = socket_create(AF_INET,SOCK_STREAM,SOL_TCP);
	$Data = cuint(3055).cuint(strlen($data)).$data;
	
	//$data = $Data;
	//$len = strlen($data);
	//echo "<br><br>len: $len <br>";
	//for ($i=0;$i<$len;$i++) {
		//echo '0x'.str_pad(dechex(ord(substr($data, $i, 1))),"2", "0", STR_PAD_LEFT).' ';
	//}		
	if(socket_connect($Socket,"127.0.0.1","29400")) {
	    socket_set_block($Socket);
		$send = socket_send($Socket,$Data,8192,0);
	    $recv = socket_recv($Socket,$buf,8192,0); 
	    socket_set_nonblock($Socket);
	    socket_close($Socket);
	}
	return $buf;
}
  
function cuint($data) {
    if($data < 64)
        return strrev(pack("C", $data));
    else if($data < 16384)
        return strrev(pack("S", ($data | 0x8000)));
    else if($data < 536870912)
        return strrev(pack("I", ($data | 0xC0000000)));
    return strrev(pack("c", -32) . pack("i", $data));
}

echo "<fieldset style='width: 50%; height: 500px; font-size:20px;'><legend>PW-CHANGE-APPOINTMENT-FACTION v1.3 by wsok.net</legend>";

if($_POST['getfaction'] != ""){
   $cfaction = explode(",", $_POST['getfaction']);
	echo "
	<form method='post'>
		<input type='hidden' style='width: 40%; height: 35px; font-size:20px;' min='1' name='roleid1' required placeholder='ID ROLE CURRENT MASTER' value='{$cfaction[3]}'>
		<input type='number' style='width: 40%; height: 35px; font-size:20px;' min='1' name='roleid2' required placeholder='ID ROLE FOR EDIT'> Player ID (must be in this clan!)<br><br>
		<select name='nedit' style='width: 40%; height: 35px; font-size:20px;'>
			<option value='6'>Member</option>
			<option value='5'>Captain</option>
			<option value='4'>Commander</option>
			<option value='3'>Vice Guild Master [ replace the current ]</option>
			<option value='2'>Guild Master [ replace the current ]</option>
		</select> 
		Position selection<br><br>
		<fieldset><legend>Clan Information</legend>
			<pre>
				<b>CLAN NAME: </b> <font color=red>[ {$cfaction[0]} ] {$cfaction[1]} </font>
				<b>NUMBER OF PLAYERS: </b> <font color=red>{$cfaction[5]} </font>
				<b>CLAN LEVEL: </b> <font color=red>{$lvl[$cfaction[2]]} </font>
				<b>CLAN MASTER (IdRole): </b> <font color=red>{$cfaction[3]}</font>
			</pre>
		</fieldset>
		<fieldset>
			<legend>Clan Announcement</legend> 
			<pre>{$cfaction[4]}</pre> 
		</fieldset> 
	</fieldset>
	<input type='hidden' style='width: 40%; height: 35px; font-size:20px;' min='1' name='fid' required placeholder='ID FACTION' value='{$cfaction[0]}'>
	<input type='submit' value='EXECUTE PURPOSE' style='width: 35%; height: 35px; font-size:20px;'></form> <a href=''>Return to clan selection</a><br><br>";
} else {
	$buf = dbread("factioninfo");
	$strlarge = unpack( "H", substr( $buf, 2, 1 ) );
	
	if(substr($strlarge[1], 0, 1) == "8"){$start = 13;}else{$start = 12;}
	
	$clancount = unpack( "c", substr( $buf, $start, 4 ) );
	$start +=7; 
	for($c=0; $i<$clancount[1]; $c++) {
		$i++;
		$clanid = unpack( "N*", substr( $buf, $start, 4 ) );
		$start += 4;
		$namelarge = unpack( "C", substr( $buf, $start, 1 ) );
		$start +=1;
		$clanname = iconv( "UTF-16", "UTF-8", substr( $buf, $start, $namelarge[1] ) );
		$start += $namelarge[1];
		$lvl = unpack( "C", substr( $buf, $start, 1 ) );
		$start +=1;
		$masterid = unpack( "N*", substr( $buf, $start, 4 ) );
		$start +=4;
		$master_role = unpack( "C", substr( $buf, $start, 1 ) );
		$start +=1;
		$numroles = unpack( "C", substr( $buf, $start, 4) );
		$start += (5*$numroles[1])+1; 
		$namelarge2 = unpack( "C", substr( $buf, $start, 1 ) );
		$start +=1;
		$news = iconv( "UTF-16", "UTF-8", substr( $buf, $start, $namelarge2[1] ) );
		$start +=$namelarge2[1]+7;
	
		$options .= "<option value='{$clanid[1]},{$clanname},{$lvl[1]},{$masterid[1]},{$news},{$numroles[1]}'>[ {$clanid[1]} ] {$clanname}</option>";				
	}
	
	if($i > 0){
		echo "<form method='post'>
			Choose a clan: <select name='getfaction' style='width: 40%; height: 35px; font-size:20px;'>$options</select><br><br>
		<input type='submit' value='CHOOSE CLAN' style='width: 35%; height: 35px; font-size:20px;'></form>";
	}else{
		echo "Clans not found, if you think that clans should be - check whether the game server is running and whether the rights to files and folders are granted.";
	}
}
echo "</fieldset>";
if (isset($_POST['roleid1']) && isset($_POST['roleid2']) && isset($_POST['fid'])) {
	$Pocket = pack("N*",-1).pack('N',$_POST['fid']).pack('N',$_POST['roleid1']).pack('N',$_POST['roleid2']).pack('C',2).pack('C',$_POST['nedit']).pack("N*",12);
	$Data = cuint(4611).cuint(strlen($Pocket)).$Pocket;
	
	$data = $Data;
	$len = strlen($data);
	echo "<br><br>len: $len <br>";
	for ($i=0;$i<$len;$i++) {
		echo '0x'.str_pad(dechex(ord(substr($data, $i, 1))),"2", "0", STR_PAD_LEFT).' ';
	}		
	die;
	//SocketSender($Data, $host="127.0.0.1", $port = "29400");
	echo"<br><b>Request completed successfully! These characters must re-enter the game..</b><br><br>";	        
} else {
	echo"<b>Enter data in the form</b><br><br>";
}
echo "<br>
<hr>Web panel editor posts in the clan v1.3 (C) webserverok.com<br>";
echo "</body></html>";
?>